ASD PROGETTO CALCIO 2019 – KIT QR

CONTENUTO
- index.html: pagina web pronta per essere pubblicata
- logo_asd_progetto_calcio.jpg: logo estratto dalla locandina fornita
- QR_ASD_Progetto_Calcio_2019.png: QR code già pronto

IL QR CODE ATTUALE
Il QR porta direttamente a WhatsApp del numero 328 429 2971 con un messaggio precompilato.
Questo funziona subito e non richiede un sito web.

PAGINA WEB
La pagina index.html è pronta per essere pubblicata su un servizio di hosting.
Una volta ottenuto un indirizzo pubblico (es. https://tuodominio.it), si può creare
un secondo QR che porta direttamente alla pagina completa.

NOTA
Il testo della pagina è stato costruito usando le informazioni leggibili nella locandina.
